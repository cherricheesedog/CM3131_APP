import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AnimequizPage } from './animequiz.page';

const routes: Routes = [
  {
    path: '',
    component: AnimequizPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AnimequizPageRoutingModule {}
