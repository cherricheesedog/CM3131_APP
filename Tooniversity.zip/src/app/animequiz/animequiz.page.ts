import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
var score;
var finalScore ='';
@Component({
  selector: 'app-animequiz',
  templateUrl: './animequiz.page.html',
  styleUrls: ['./animequiz.page.scss'],
})
export class AnimequizPage implements OnInit {
  animeQuestions; any;
  constructor(private http: HttpClient) { }

  ngOnInit() {
    score = 0;
    this.http.get('https://opentdb.com/api.php?amount=25&category=31').subscribe((resp) => {
      this.animeQuestions = resp;
      console.log(this.animeQuestions);
    });
  
  }

  correct_clicked(){
    score = score + 1;
    console.log(score + ":25");
    }

  incorrect_clicked(){
    score = score - 1;
    console.log(score + ":25");
    }

    storeScore(){
      finalScore = score.toString();
      console.log(finalScore);
      sessionStorage.setItem("finalScore", finalScore);
    }

  }



