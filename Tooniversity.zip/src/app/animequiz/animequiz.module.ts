import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AnimequizPageRoutingModule } from './animequiz-routing.module';

import { AnimequizPage } from './animequiz.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AnimequizPageRoutingModule
  ],
  declarations: [AnimequizPage]
})
export class AnimequizPageModule {}
