declare var require: any
import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
var score;
var finalScore ='';
@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.page.html',
  styleUrls: ['./quiz.page.scss'],
})
export class QuizPage implements OnInit {
 toonQuestions; any;
  constructor(private http: HttpClient) { }

  ngOnInit() {
    score = 0;
    this.http.get('https://opentdb.com/api.php?amount=25&category=32').subscribe((response) => {
      this.toonQuestions= response;
      console.log(this.toonQuestions); 
    });
   
}

correct_clicked(){
  score = score + 1;
  console.log(score + ":25 ");
}
incorrect_clicked(){
  score = score - 1;
  console.log(score + ":25");
}

storeScore(){
  finalScore = score.toString();
  console.log(finalScore);
  sessionStorage.setItem("finalScore", finalScore);
}

}