import { Component, OnInit} from '@angular/core';
var totalScore;
var userRank;
var rankDescrip;
@Component({
  selector: 'app-results',
  templateUrl: './results.page.html',
  styleUrls: ['./results.page.scss'],
})
export class ResultsPage implements OnInit {

  constructor() { }

  ngOnInit() {
     totalScore = parseInt(sessionStorage.getItem("finalScore"));
    var displayScore = document.getElementById("score_display");
    displayScore.innerHTML = totalScore + "/25";

    userRank = document.getElementById("rank");
    rankDescrip = document.getElementById("rank_desc");
    if(totalScore < 7){
      userRank.innerHTML = "Rank: Dropout";
      rankDescrip.innerHTML = "You may want to clear your schedule if you want to graduate as you knowledge is quite lacking adn you are going to need to do some essential reading.";
    } else if (totalScore >= 7 && totalScore <= 12){
      userRank.innerHTML = "Rank: Freshman";
      rankDescrip.innerHTML = "You may not know everything but it is clear that you have some passion and know a bit about animation.";
    } else if (totalScore >= 13 && totalScore <= 17){
      userRank.innerHTML = "Rank: Bachelors";
      rankDescrip.innerHTML = " It is clear you have invested some time into the world of drawings and polygons. You know your Simpsons, Spongebobs and your Cowboy Bebops. You deserve to throw your cap in the air.";
    } else if (totalScore >= 18 && totalScore <= 21){
      userRank.innerHTML = "Rank: Masters";
      rankDescrip.innerHTML ="Not only do you have a bachelors in animation, but you put your knowledge and passion for the medium to the next level by undergoing postgraduate studies.";
    } else if (totalScore >= 22 && totalScore <= 25){
      userRank.innerHTML = "Rank: PhD";
      rankDescrip.innerHTML = "Your dedication to those 24 frames is underestimated. You have gained and sacrified to get to this point. Turnaround sheets and walk cycles are second nature to you. It is my honour to present you your doctorate.";
    }

  }

  }



